# PULPOS — Punto de venta offline para Windows

Funciona **100% sin internet**. Un computador con Windows hace de caja principal y guarda todo; los meseros pueden usar ese mismo equipo o sus celulares/tablets conectados a la misma red WiFi local (un router o la zona WiFi de un celular, sin datos).

## Instalar
- **PULPOS-Instalador-1.4.2.exe**: asistente de instalación en español. Crea accesos directos en el escritorio y en el menú Inicio. Si ya hay una versión anterior instalada, la quita sola y la reemplaza. Sus datos (Documentos\POS Eventos) no se borran.
- **PULPOS-Portable-1.4.2.exe**: no se instala, se abre con doble clic (sirve desde una USB).

## Activación (primera vez)
La primera vez que se abre en una computadora, PULPOS muestra la pantalla **Activar PULPOS** con un **código de equipo** (XXXX-XXXX-XXXX-XXXX). Copie ese código y envíelo a su proveedor de PULPOS. Él le devuelve una **clave de activación**. Péguela en la casilla y pulse **Activar**. La clave sirve solo para esa computadora, y algunas tienen fecha de vencimiento. Cuando vence, el programa vuelve a pedir una clave. Los celulares de los meseros no necesitan clave.

Windows puede mostrar "Windows protegió su PC" porque la app no está firmada: haga clic en **Más información → Ejecutar de todas formas**. Si aparece el aviso del Firewall, marque **Redes privadas → Permitir acceso** (es lo que deja entrar a los celulares de los meseros).

## Usuarios de prueba (cámbielos en Ajustes → Usuarios)
Mientras se usen los PIN de fábrica, Ajustes muestra un aviso para cambiarlos. Los PIN nuevos deben tener de 4 a 8 números y no pueden ser fáciles de adivinar (1234, 0000, números repetidos) ni repetirse entre usuarios.

| Usuario | PIN | Puede |
|---|---|---|
| Administrador | 1234 | Todo: productos, precios, usuarios, reportes, cerrar evento |
| Caja | 2222 | Abrir/cerrar caja, vender, cobrar, anular, ver ventas |
| Mesero 1 | 1111 | Tomar pedidos por mesa, agregar productos, ver comandas |

## Cómo se usa
1. **Vender**: toque los productos (o escriba en el buscador y pulse **Enter** para agregar el primero), toque **Elegir mesa** y pulse **Enviar pedido** (queda abierto en la mesa) o **Cobrar** directamente. En **Elegir mesa** las mesas en naranja ya tienen una cuenta abierta: al tocarla se sigue ese pedido.
2. **Mesas**: muestra mesas libres/ocupadas y lo que debe cada una. Toque una mesa para agregar más productos o cobrarla.
3. **Comandas**: pantalla para cocina o barra; se marcan los productos listos.
4. **Ventas**: total vendido, por forma de pago, por mesero, por producto, propinas; exportar a Excel (CSV) y reimprimir recibos.
5. **Ajustes**: nombre del evento, moneda, número de mesas, impuesto, si los meseros pueden cobrar, productos, categorías, usuarios, respaldo y **Cerrar evento** (guarda copia y deja todo en cero).

## Impresoras y comandas
En Ajustes › **Impresoras** elija (de las impresoras instaladas en Windows):
- **Impresora de recibos / caja**: recibos, pre-cuentas y reportes de cierre de caja.
- **Estaciones de comandas** (ej. COCINA y BARRA): cada una con su impresora y las categorías que le corresponden. Al enviar un pedido (desde la caja o desde el celular de un mesero) la comanda sale sola en cada estación con la mesa, el número de pedido y el **nombre del mesero que lo digitó**. Si luego se agregan productos sale una comanda "ADICIONAL" solo con lo nuevo, y si caja quita algo sale "CANCELAR".
- Botón **Probar** para verificar cada impresora y botón 🖨 para reimprimir comandas desde Mesas o Comandas.
La impresora debe estar instalada en Windows con su driver (térmicas de 80 mm o 58 mm, USB o red).

## Impresoras de red (con IP)
Si la impresora térmica está conectada al router por cable o WiFi, no hace falta instalarla en Windows. En **Ajustes › Impresoras › Agregar impresora de red** escriba un nombre, la IP (sale en la hoja de autoprueba de la impresora) y el puerto (normalmente 9100). Pulse **Probar conexión** y guarde. Luego elíjala como impresora de recibos o de una estación de comandas. La impresora debe estar en la misma red que el computador de la caja.

## Zonas y mesas
En **Ajustes › Zonas y mesas** se crean las zonas del lugar (Salón, VIP, Terraza...) indicando cuántas mesas tiene cada una. Las mesas pueden ir numeradas (21, 22...) o con el nombre de la zona (VIP 1, VIP 2...). Tocando una mesa se puede renombrar, pasar a otra zona o eliminar. Una mesa con un pedido abierto no se puede borrar ni renombrar hasta cobrarla. En la pestaña **Mesas** las mesas salen agrupadas por zona, con botones para filtrar, y la comanda impresa lleva la mesa y la zona.

## Asientos y cuentas divididas
Al tomar el pedido toque **+ Asiento** para cada persona, elija el asiento y toque los productos: quedan cargados a ese asiento (o a "Compartido"). Al cobrar puede elegir **Todo**, **Por asiento**, **Por producto** o **Partes iguales**, y en cada cobro combinar formas de pago (**pago mixto**: efectivo + tarjeta + transferencia). Cada pago parcial imprime su recibo con el saldo pendiente.

## Factura
En Ajustes complete nombre del negocio, lema, NIT, dirección, teléfono, Instagram y cargue el **logo**. La factura sale con letra gruesa en columnas (UD / DESCRIPCIÓN / PRECIO / IMPORTE).

## Caja: apertura y cierre
En la pestaña **Caja** se abre la caja con la base de efectivo (no se puede cobrar con la caja cerrada). Durante el evento se registran ingresos y retiros de efectivo. Al cerrar se escribe el efectivo contado y el sistema muestra si cuadra, sobra o falta, e imprime el reporte (ventas por forma de pago, por mesero, propinas, retiros y firma). Los cierres anteriores quedan en el historial.

## Productos con foto
En **Ajustes › Productos** se ven todos los productos en tarjetas, con buscador, filtro por categoría y un interruptor para mostrarlos u ocultarlos en la venta. Al crear o editar uno, arrastre la foto (o haga clic para elegirla) y la tarjeta se ve en vivo mientras escribe. Si no carga foto, se muestra con su **color**. El botón **Guardar y crear otro** sirve para cargar muchos productos seguidos.

## Inventario y ganancias
En la pestaña **Inventario** (solo administrador) pulse **Cargar inventario** cuando le entreguen mercancía. Escriba, para cada producto, cuánto entra y lo que costó cada unidad, y verá cuánto gana por unidad. Cada venta descuenta el stock sola, y si se anula un pedido, el stock vuelve. En la pantalla de vender, los productos muestran **Quedan N** o **Agotado**. Con el interruptor **No vender si no hay stock** se puede impedir vender lo agotado. **Contar** sirve para corregir con un conteo físico o para dejar de controlar un producto. El reporte muestra lo cargado, lo vendido, el costo de lo vendido, la **ganancia** con su margen y **lo que quedó** con su valor. Se puede ver en pantalla, imprimir en la ticketera o bajar a Excel. Al **Cerrar evento**, lo que sobró pasa como inventario inicial del siguiente.

## PULPOS web (ventas en el panel)
En **Ajustes › PULPOS web** se conecta este equipo al panel web: en el panel entre a **Negocios › PCs**, genere un código de 6 números y escríbalo aquí. Desde entonces, las ventas cobradas y anuladas, los cierres de caja y el inventario suben solos cuando hay internet. La caja nunca espera a internet. Si no hay conexión, todo queda guardado en el equipo y sube después, sin duplicar nada, incluso si el evento ya se cerró. En esa misma pantalla se ve la última sincronización y lo que falta por subir.

## Empezar en Mesas
En **Ajustes › Negocio y factura** el interruptor **Empezar en Mesas** hace que al entrar (y después de enviar un pedido) se abra la pantalla de Mesas en vez de Vender. Apagado, todo empieza en Vender como antes.

## Seguridad
- Los PIN se guardan cifrados. Tras 5 PIN equivocados seguidos el ingreso se bloquea unos segundos (cada vez más).
- Una sesión se cierra sola tras 14 horas sin uso, y al cambiar el PIN de un usuario.
- Los precios siempre salen del catálogo de la PC; un celular no puede cambiarlos.
- Un pedido ya cobrado no se puede anular sin que un administrador lo reabra.
- Al restaurar un respaldo se revisa el archivo y se cierran todas las sesiones.

## Modo oscuro
El botón de la luna, arriba a la derecha, cambia entre modo claro y oscuro. Cada computadora o celular recuerda su elección.

## Meseros con celular
En **Ajustes › Conectar celulares** aparece un **código QR** y una dirección tipo `http://192.168.1.10:3000`. Con el celular en la misma WiFi, escanéelo o escríbala en el navegador, ingrese el PIN y listo. Todos los dispositivos se actualizan al instante. Lo que se imprime desde el celular (comandas, pre-cuentas, recibos) sale por las impresoras conectadas a la PC, así que la app debe estar abierta en la PC.

## Datos
Se guardan solos en `Documentos\POS Eventos\datos-pos.json`. Las copias al cerrar evento quedan en `Documentos\POS Eventos\cierres`. Recibos: impresora térmica de 80 mm o cualquier impresora (casilla "Imprimir recibo" al cobrar).

## Para programadores
```
npm install
npm start            # abre la app de escritorio
npm run servidor     # solo el servidor (http://localhost:3000)
npm run build:win    # genera el instalador en dist/ (en Linux requiere wine64 y wine32)
```
